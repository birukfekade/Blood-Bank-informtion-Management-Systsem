export class Donationcenter {
  constructor(
    public id?: string,
    public dcid?: string,
    public dcname?: string,
    public  branch?: string,
    public  city?: string,
    public region?: string,
    public  zone?: string,
    public  woreda?: string,
    public  kebele?: string
  )
  {
  }

}
