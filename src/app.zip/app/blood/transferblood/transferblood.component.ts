import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transferblood',
  templateUrl: './transferblood.component.html',
  styleUrls: ['./transferblood.component.css']
})
export class TransferbloodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
