import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addblood',
  templateUrl: './addblood.component.html',
  styleUrls: ['./addblood.component.css']
})
export class AddbloodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
