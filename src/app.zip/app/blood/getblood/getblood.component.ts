import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getblood',
  templateUrl: './getblood.component.html',
  styleUrls: ['./getblood.component.css']
})
export class GetbloodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
