import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css', '../../assets/css/jquery.dataTables.css']
})
export class StaffComponent implements OnInit {
  public data =
    [{
      'staffid': 'STAFF 6538',
      'firstname': 'Solome',
      'lastname': 'Natty',
      'gfname': 'Kidane',
      'sex': 'Female',
      'title': 'Blood Collector',
      'branch': 'Mekele',
      'telephone': '0116851018',
      'phonenumber': '0910012563',
      'email': 'zaku@yahoo.com',
      'pobox' : '46532102'
    },
      {
        'staffid': 'STAFF 6538',
        'firstname': 'Solome',
        'lastname': 'Natty',
        'gfname': 'Kidane',
        'sex': 'Female',
        'title': 'Blood Collector',
        'branch': 'Mekele',
        'telephone': '0116851018',
        'phonenumber': '0910012563',
        'email': 'zaku@yahoo.com',
        'pobox' : '46532102'
      },
      {
        'staffid': 'STAFF 6538',
        'firstname': 'Solome',
        'lastname': 'Natty',
        'gfname': 'Kidane',
        'sex': 'Female',
        'title': 'Blood Collector',
        'branch': 'Mekele',
        'telephone': '0116851018',
        'phonenumber': '0910012563',
        'email': 'zaku@yahoo.com',
        'pobox' : '46532102'
      },
      {
        'staffid': 'STAFF 6538',
        'firstname': 'Solome',
        'lastname': 'Natty',
        'gfname': 'Kidane',
        'sex': 'Female',
        'title': 'Blood Collector',
        'branch': 'Mekele',
        'telephone': '0116851018',
        'phonenumber': '0910012563',
        'email': 'zaku@yahoo.com',
        'pobox' : '46532102'
      },
      {
        'staffid': 'STAFF 6538',
        'firstname': 'Solome',
        'lastname': 'Natty',
        'gfname': 'Kidane',
        'sex': 'Female',
        'title': 'Blood Collector',
        'branch': 'Mekele',
        'telephone': '0116851018',
        'phonenumber': '0910012563',
        'email': 'zaku@yahoo.com',
        'pobox' : '46532102'
      },
      {
        'staffid': 'STAFF 6538',
        'firstname': 'Solome',
        'lastname': 'Natty',
        'gfname': 'Kidane',
        'sex': 'Female',
        'title': 'Blood Collector',
        'branch': 'Mekele',
        'telephone': '0116851018',
        'phonenumber': '0910012563',
        'email': 'zaku@yahoo.com',
        'pobox' : '46532102'
      },
      {
      'staffid': 'STAFF 6538',
      'firstname': 'Solome',
      'lastname': 'Natty',
      'gfname': 'Kidane',
      'sex': 'Female',
      'title': 'Blood Collector',
      'branch': 'Mekele',
      'telephone': '0116851018',
      'phonenumber': '0910012563',
      'email': 'zaku@yahoo.com',
      'pobox' : '46532102'
    },
      {
        'staffid': 'STAFF 6538',
        'firstname': 'Solome',
        'lastname': 'Natty',
        'gfname': 'Kidane',
        'sex': 'Female',
        'title': 'Blood Collector',
        'branch': 'Mekele',
        'telephone': '0116851018',
        'phonenumber': '0910012563',
        'email': 'zaku@yahoo.com',
        'pobox' : '46532102'
      }
    ];

  public tableWidget: any;

  public selectedName= '';


  constructor() { }

  ngOnInit() {
    $(document).ready(function () {
      const dataTable = $('#example').DataTable({
        'scrollX': true,
      });
    });

  }

  // ngAfterViewInit() {
  //   this.initDatatable();
  // }

  private initDatatable(): void {
    debugger;
    const exampleId: any = $('#example');
    this.tableWidget = exampleId.DataTable({
      select: true
    });

  }


  public selectRow(index: number, row: any) {
    this.selectedName = 'row#' + index + ' ' + row.name;
  }

}
