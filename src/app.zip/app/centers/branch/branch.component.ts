import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import 'datatables.net';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.css', '../../../assets/css/jquery.dataTables.css']
})
export class BranchComponent implements OnInit {
  public data =
    [{
      'branchid': 'BRANCH 0009',
      'branchname': 'Stadium',
      'city': 'Addis Ababa',
      'region': 'Addis Ababa',
      'zone': 'Kera zone 3',
      'woreda': '05',
      'kebele': '01',
      'phonenumber': '0113525986',
      'postnumber': 'Addis 5632s',
      'admin' : 'solome'
    },
      {
        'branchid': 'BRANCH 0009',
        'branchname': 'Stadium',
        'city': 'Addis Ababa',
        'region': 'Addis Ababa',
        'zone': 'Kera zone 3',
        'woreda': '05',
        'kebele': '01',
        'phonenumber': '0113525986',
        'postnumber': 'Addis 5632s',
        'admin' : 'solome'
      }
      ,
      {
        'branchid': 'BRANCH 0009',
        'branchname': 'Stadium',
        'city': 'Addis Ababa',
        'region': 'Addis Ababa',
        'zone': 'Kera zone 3',
        'woreda': '05',
        'kebele': '01',
        'phonenumber': '0113525986',
        'postnumber': 'Addis 5632s',
        'admin' : 'solome'
      }
      ,
      {
        'branchid': 'BRANCH 0009',
        'branchname': 'Stadium',
        'city': 'Addis Ababa',
        'region': 'Addis Ababa',
        'zone': 'Kera zone 3',
        'woreda': '05',
        'kebele': '01',
        'phonenumber': '0113525986',
        'postnumber': 'Addis 5632s',
        'admin' : 'solome'
      }
      ,
      {
        'branchid': 'BRANCH 0009',
        'branchname': 'Stadium',
        'city': 'Addis Ababa',
        'region': 'Addis Ababa',
        'zone': 'Kera zone 3',
        'woreda': '05',
        'kebele': '01',
        'phonenumber': '0113525986',
        'postnumber': 'Addis 5632s',
        'admin' : 'solome'
      },
      {
        'branchid': 'BRANCH 0009',
        'branchname': 'Stadium',
        'city': 'Addis Ababa',
        'region': 'Addis Ababa',
        'zone': 'Kera zone 3',
        'woreda': '05',
        'kebele': '01',
        'phonenumber': '0113525986',
        'postnumber': 'Addis 5632s',
        'admin' : 'solome'
      }
      ,
      {
        'branchid': 'BRANCH 0009',
        'branchname': 'Stadium',
        'city': 'Addis Ababa',
        'region': 'Addis Ababa',
        'zone': 'Kera zone 3',
        'woreda': '05',
        'kebele': '01',
        'phonenumber': '0113525986',
        'postnumber': 'Addis 5632s',
        'admin' : 'solome'
      },
      {
        'branchid': 'BRANCH 0009',
        'branchname': 'Stadium',
        'city': 'Addis Ababa',
        'region': 'Addis Ababa',
        'zone': 'Kera zone 3',
        'woreda': '05',
        'kebele': '01',
        'phonenumber': '0113525986',
        'postnumber': 'Addis 5632s',
        'admin' : 'solome'
      }
      ,
      {
        'branchid': 'BRANCH 0009',
        'branchname': 'Stadium',
        'city': 'Addis Ababa',
        'region': 'Addis Ababa',
        'zone': 'Kera zone 3',
        'woreda': '05',
        'kebele': '01',
        'phonenumber': '0113525986',
        'postnumber': 'Addis 5632s',
        'admin' : 'solome'
      }
      ,
      {
        'branchid': 'BRANCH 0009',
        'branchname': 'Stadium',
        'city': 'Addis Ababa',
        'region': 'Addis Ababa',
        'zone': 'Kera zone 3',
        'woreda': '05',
        'kebele': '01',
        'phonenumber': '0113525986',
        'postnumber': 'Addis 5632s',
        'admin' : 'solome'
      }
      ,
      {
        'branchid': 'BRANCH 0009',
        'branchname': 'Stadium',
        'city': 'Addis Ababa',
        'region': 'Addis Ababa',
        'zone': 'Kera zone 3',
        'woreda': '05',
        'kebele': '01',
        'phonenumber': '0113525986',
        'postnumber': 'Addis 5632s',
        'admin' : 'solome'
      },
      {
      'branchid': 'BRANCH 0009',
      'branchname': 'Stadium',
      'city': 'Addis Ababa',
      'region': 'Addis Ababa',
      'zone': 'Kera zone 3',
      'woreda': '05',
      'kebele': '01',
      'phonenumber': '0113525986',
      'postnumber': 'Addis 5632s',
      'admin' : 'solome'
    }

    ];

  public tableWidget: any;

  public selectedName= '';


  constructor() { }

  ngOnInit() {
    $(document).ready(function () {
      const dataTable = $('#example').DataTable({
        'scrollX': true,
      });
    });

  }

  // ngAfterViewInit() {
  //   this.initDatatable();
  // }

  private initDatatable(): void {
    debugger;
    const exampleId: any = $('#example');
    this.tableWidget = exampleId.DataTable({
      select: true,
      'scrollX': true
    });
    //   $('#example')
    //     .removeClass('display')
    //     .addClass('table table-striped table-bordered')
  }

  // private reInitDatatable(): void {
  //   if (this.tableWidget) {
  //     this.tableWidget.destroy();
  //     this.tableWidget = null;
  //   }
  //   setTimeout(() => this.initDatatable(), 0);
  // }

  public selectRow(index: number, row: any) {
    this.selectedName = 'row#' + index + ' ' + row.name;
  }

}

