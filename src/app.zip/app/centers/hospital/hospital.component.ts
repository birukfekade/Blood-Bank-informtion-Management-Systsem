import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import 'datatables.net';


@Component({
  selector: 'app-hospital',
  templateUrl: './hospital.component.html',
  styleUrls: ['./hospital.component.css']
})
export class HospitalComponent implements OnInit {
  public data =
    [ {
      'hospitalid': 'Hospital 4544',
      'hospitalname': 'Mehalmeda',
      'branchname': 'Debire Birhan',
      'city': 'City',
      'region': 'Region',
      'zone': 'North Shewa',
      'woreda': 'Menz Gera',
      'kebele': '01',
      'phonenumber': '091131546',
      'postnumber': 'Addis a45',
      'admin': 'Hana'
    },
      {
        'hospitalid': 'Hospital 4544',
        'hospitalname': 'Mehalmeda',
        'branchname': 'Debire Birhan',
        'city': 'City',
        'region': 'Region',
        'zone': 'North Shewa',
        'woreda': 'Menz Gera',
        'kebele': '01',
        'phonenumber': '091131546',
        'postnumber': 'Addis a45',
        'admin': 'Hana'
      },
      {
        'hospitalid': 'Hospital 4544',
        'hospitalname': 'Mehalmeda',
        'branchname': 'Debire Birhan',
        'city': 'City',
        'region': 'Region',
        'zone': 'North Shewa',
        'woreda': 'Menz Gera',
        'kebele': '01',
        'phonenumber': '091131546',
        'postnumber': 'Addis a45',
        'admin': 'Hana'
      },
      {
        'hospitalid': 'Hospital 4544',
        'hospitalname': 'Mehalmeda',
        'branchname': 'Debire Birhan',
        'city': 'City',
        'region': 'Region',
        'zone': 'North Shewa',
        'woreda': 'Menz Gera',
        'kebele': '01',
        'phonenumber': '091131546',
        'postnumber': 'Addis a45',
        'admin': 'Hana'
      },
      {
        'hospitalid': 'Hospital 4544',
        'hospitalname': 'Mehalmeda',
        'branchname': 'Debire Birhan',
        'city': 'City',
        'region': 'Region',
        'zone': 'North Shewa',
        'woreda': 'Menz Gera',
        'kebele': '01',
        'phonenumber': '091131546',
        'postnumber': 'Addis a45',
        'admin': 'Hana'
      },
      {
        'hospitalid': 'Hospital 4544',
        'hospitalname': 'Mehalmeda',
        'branchname': 'Debire Birhan',
        'city': 'City',
        'region': 'Region',
        'zone': 'North Shewa',
        'woreda': 'Menz Gera',
        'kebele': '01',
        'phonenumber': '091131546',
        'postnumber': 'Addis a45',
        'admin': 'Hana'
      }
    ];

  public tableWidget: any;

  public selectedName= '';


  constructor() { }

  ngOnInit() {
    $(document).ready(function () {
      const dataTable = $('#example').DataTable({
        'scrollX': true,
      });
    });

  }

  ngAfterViewInit() {
    this.initDatatable();
  }

  private initDatatable(): void {
    debugger;
    const exampleId: any = $('#example');
    this.tableWidget = exampleId.DataTable({
      select: true,
      'scrollX': true
    });
    //   $('#example')
    //     .removeClass('display')
    //     .addClass('table table-striped table-bordered')
  }

  private reInitDatatable(): void {
    if (this.tableWidget) {
      this.tableWidget.destroy();
      this.tableWidget = null;
    }
    setTimeout(() => this.initDatatable(), 0);
  }


  public selectRow(index: number, row: any) {
    this.selectedName = 'row#' + index + ' ' + row.name;
  }

}
