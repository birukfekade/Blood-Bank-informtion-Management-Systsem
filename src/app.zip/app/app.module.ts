import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { BranchComponent } from './centers/branch/branch.component';
import { UserComponent } from './user/user.component';
import {FooterComponent} from './common/footer/footer.component';
import {NavbarComponent} from './common/navbar/navbar.component';
import {NewnavComponent} from './common/newnav/newnav.component';
import {HospitalComponent} from './centers/hospital/hospital.component';
import {DonationcenterComponent} from './centers/donationcenter/donationcenter.component';
import {DonorComponent} from './donor/donor.component';
import {StaffComponent} from './staff/staff.component';
import {AddbloodComponent} from './blood/addblood/addblood.component';
import {DonateComponent} from './blood/donate/donate.component';
import {GetbloodComponent} from './blood/getblood/getblood.component';
import {TransferbloodComponent} from './blood/transferblood/transferblood.component';
import {Routes,RouterModule} from '@angular/router';
import { DatatableComponent } from './common/datatable/datatable.component';
import {TrialpostComponent} from './common/trialpost/trialpost.component';
import {hostname} from 'os';


const appRoutes: Routes = [

  { path: 'branch', component: BranchComponent},
  { path: 'user', component: UserComponent},
  { path: 'dt', component: DatatableComponent},
  {path: 'nav', component: NavbarComponent},
  {path: 'dnav', component: NewnavComponent},
  {path: 'hospital', component: HospitalComponent},
  {path: 'donationcenter', component: DonationcenterComponent},
  {path: 'donor', component: DonorComponent},
  {path: 'staff', component: StaffComponent},
  {path:  'tp', component: TrialpostComponent},
  {path: 'addblood', component: AddbloodComponent},
  {path: 'donate', component: DonateComponent},
  {path: 'getblood', component: GetbloodComponent},
  {path: 'transferblood', component: TransferbloodComponent}


];

@NgModule({
  declarations: [
    AppComponent,
    BranchComponent,
    UserComponent,
    FooterComponent,
    DatatableComponent,
    NavbarComponent,
    NewnavComponent,
    HospitalComponent,
    DonationcenterComponent,
    DonorComponent,
    StaffComponent,
    AddbloodComponent,
    DonateComponent,
    GetbloodComponent,
    TransferbloodComponent,
    TrialpostComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
