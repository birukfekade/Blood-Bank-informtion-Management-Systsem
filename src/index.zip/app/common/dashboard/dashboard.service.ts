import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Staff} from '../../user/staff/staff';
import {Headers, Http} from '@angular/http';
import {AuthenticateService} from '../../authenticate/authenticate.service';


@Injectable()
export class DashboardService {

  serverUrl = 'http://localhost:3000/api';

  constructor(private http: Http, private authservice: AuthenticateService) { }

  headers = new Headers({
    'Content-Type': 'application/json',
    'Authorization': this.authservice.getToken()
  });

  getStaffs(): Observable<Staff[]> {

    const  url = this.serverUrl + '/staffs/count';
    return this.http.get(url, {headers: this.headers}).map(res => res.json()).catch(err => {
      return Observable.throw(err);
    });
  }

}
