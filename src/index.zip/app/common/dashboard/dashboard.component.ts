import { Component, OnInit } from '@angular/core';
import {DashboardService} from './dashboard.service';
import {Staff} from '../../user/staff/staff';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  providers: [DashboardService]
})
export class DashboardComponent implements OnInit {
public noofstaff;

  staffs: Staff[] = [];
  constructor(private dashboardservice: DashboardService) { }

  ngOnInit() {
    this.yeah();

  }

  yeah() {
 this.dashboardservice.getStaffs().subscribe(res => {
   this.noofstaff = res.toString();
    });
  }


}
