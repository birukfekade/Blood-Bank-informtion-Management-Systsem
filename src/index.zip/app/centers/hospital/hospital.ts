export class Hospital {
  constructor(
    public id?: string,
    public hospitalid?: string,
    public hospitalname?: string,
    public  branchid?: string,
    public  city?: string,
    public region?: string,
    public  zone?: string,
    public  woreda?: string,
    public  kebele?: string,
    public  telephone?: string,
    public pobox?: string,
    public  administrator?: string
  )
  {
  }

}
