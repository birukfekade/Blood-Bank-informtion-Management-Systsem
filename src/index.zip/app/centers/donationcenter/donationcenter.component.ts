import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import 'datatables.net';
import {DonationcenterService} from './donationcenter.service';
import {Donationcenter} from '../../bbims/post';
import {Router} from '@angular/router';

@Component({
  selector: 'app-donationcenter',
  templateUrl: './donationcenter.component.html',
  // styleUrls: ['./donationcenter.component.css'],
  styleUrls: ['./donationcenter.component.css'],
  providers: [DonationcenterService]
})
export class DonationcenterComponent implements OnInit {
  donationcenters: Donationcenter[] = [];
  donationcenter: Donationcenter = new Donationcenter();
 updatedData: Donationcenter = new Donationcenter();
  errorMessage = '';
  public tableWidget: any;

  public selectedName = '';
  public selectedId = '';
  public selectedDcid = '';
  public selectedDcname = '';
  public selectedDcbranch = '';
  public selectedDccity = '';
  public selectedDcregion = '';
  public selectedDczone = '';
  public selectedDcworeda = '';
  public selectedDckebele = '';

  constructor(private donationcenterService: DonationcenterService, private  router: Router) {
  }

  ngOnInit(): void {
    this.pop();


    $( document ).ready( function () {
      const dataTable = $( '#example' ).DataTable( {
        'scrollX': true,
        // 'ajax': {
        //   url : this.dona ,
        // }
      } );

    });

    // const exampleId: any = $('#example');
    // this.tableWidget = exampleId.DataTable({
    //   select: true,
    //   'scrollX': true,
    // });
      $('#example')
        .removeClass('display')
        .addClass('table table-striped table-bordered');
  }


  pop() {
    this.donationcenterService.getDonationcenters().subscribe( res => {
      console.log( res );
      this.donationcenters = res as Donationcenter[];
    }, err => {
      console.log( err );
    } );
  }

  onSubmit() {
    console.log(this.donationcenter);
    this.donationcenterService.createDonationcenter( this.donationcenter ).subscribe( res => {
      console.log( res.id );
      this.router.navigate( ['/donationcenter'] );

    }, err => {
      console.log( err );

      this.errorMessage = 'An Error Saving the Post';
    } );
  }

  public selectRow(index: number, post: any, value: string) {
    this.selectedId = post.id;
    this.selectedDcid = post.dcid;
    this.selectedDcname = post.dcname;
    this.selectedDcbranch = post.branch;
    this.selectedDccity = post.city;
    this.selectedDcregion = post.region;
    this.selectedDczone = post.zone;
    this.selectedDcworeda = post.woreda;
    this.selectedDckebele = post.kebele;
    // this.selectedName = 'post#' + index + ' ' + post.dcid;
       if (value === 'none') {

    } else if (value === 'delete') {
      this.onDelete();
    }
  }

  onUpdate() {

    this.updatedData = { id: this.selectedId, dcid: this.selectedDcid, dcname: this.selectedDcname, branch: this.selectedDcbranch,
      city: this.selectedDccity, region: this.selectedDcregion, zone: this.selectedDczone, woreda: this.selectedDcworeda, kebele: this.selectedDckebele};
    this.donationcenterService.updateDonationcenter( this.updatedData ).subscribe( res => {
      this.pop();
      // alert('Hey Dude');
    } );
  };


  onDelete() {
    this.donationcenterService.deleteDonationcenter( this.selectedId ).subscribe( res => {
    this.pop();
    } );
  };
}
