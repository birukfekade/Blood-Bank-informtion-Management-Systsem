import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bbims',
  templateUrl: './bbims.component.html',
  styleUrls: ['./bbims.component.css']
})
export class BbimsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
