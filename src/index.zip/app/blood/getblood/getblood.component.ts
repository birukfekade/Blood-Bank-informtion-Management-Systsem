import { Component, OnInit } from '@angular/core';
import {Bloodstock} from '../../stock/bloodstock/bloodstock';
import {BloodstockService} from '../../stock/bloodstock/bloodstock.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-getblood',
  templateUrl: './getblood.component.html',
  styleUrls: ['./getblood.component.css'],
  providers: [BloodstockService]
})
export class GetbloodComponent implements OnInit {

  bloodstock: Bloodstock = new Bloodstock();
  newval = 0;
  constructor(private bloodstockservice: BloodstockService , private router: Router) { }

  ngOnInit() {
    this.bloodstock.id = '5ccbe92dc87735419c995872';
    this.bloodstock.branchid = 'bra 41';
    this.bloodstock.stockid = "stock 1245";

  }
  onAsk() {
    console.log(this.bloodstock);
    this.bloodstock.available = String( 25610 - this.newval );
    this.bloodstockservice.updateBloodstock(this.bloodstock).subscribe( res => {
      console.log( res.id );
      this.router.navigate( ['/addblood'] );

    }, err => {
      console.log( err );

      // this.errorMessage = 'An Error Saving the Post';
    } );
  }

  onSend() {
    console.log(this.bloodstock);
    this.bloodstock.available = String( 25610 - this.newval );
    this.bloodstockservice.updateBloodstock(this.bloodstock).subscribe( res => {
      console.log( res.id );
      this.router.navigate( ['/addblood'] );

    }, err => {
      console.log( err );

      // this.errorMessage = 'An Error Saving the Post';
    } );
  }
}
