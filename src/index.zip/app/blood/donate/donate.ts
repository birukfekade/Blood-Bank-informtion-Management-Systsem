export class Donationhistory {
  constructor(
    public id?: string,
    public donorid?: string,
    public branchid?: string,
    public  packnumber?: string,
    public  weight?: number,
    public height?: number,
    public  pressure?: string,
    public  amount?: number,
    public  type?: string,
  public approvedby?: string
  )
  {
  }

}
