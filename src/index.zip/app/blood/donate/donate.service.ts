import { Injectable } from '@angular/core';
import {Headers, Http} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {Donationhistory} from './donate';

@Injectable()
export class DonateService {

  serverUrl = 'http://localhost:3000/api';
  constructor(private  http: Http) { }
  headers = new Headers({
    'Content-Type': 'application/json',
  });

  createDonate(donate: Donationhistory): Observable<any> {
    const  url = this.serverUrl + '/donationhistories';
    return this.http.post(url, donate, { headers: this.headers }).map(res => res.json()).catch(err => {

      return Observable.throw(err);

    });
  }

}
