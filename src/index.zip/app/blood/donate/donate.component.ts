import { Component, OnInit } from '@angular/core';
import {Donationhistory} from './donate';
import {DonateService} from './donate.service';

import {Router} from '@angular/router';
import * as $ from 'jquery';

@Component({
  selector: 'app-donate',
  templateUrl: './donate.component.html',
  styleUrls: ['./donate.component.css'],
  providers: [DonateService]
})
export class DonateComponent implements OnInit {

  donations: Donationhistory[] = [];
  donate: Donationhistory = new Donationhistory();
  errorMessage = '';
  public tableWidget: any;


  constructor(private donateservice: DonateService, private  router: Router) {
  }

  ngOnInit(): void {
    // this.pop();


    $( document ).ready( function () {
      const dataTable = $( '#example' ).DataTable( {
        'scrollX': true,
        // 'ajax': {
        //   url : this.dona ,
        // }
      } );

    } );

    // const exampleId: any = $('#example');
    // this.tableWidget = exampleId.DataTable({
    //   select: true,
    //   'scrollX': true,
    // });
    $( '#example' )
      .removeClass( 'display' )
      .addClass( 'table table-striped table-bordered' );
  }

  //
  // pop() {
  //   this.donateservice.getDonationcenters().subscribe( res => {
  //     console.log( res );
  //     this.donationcenters = res as Donationcenter[];
  //   }, err => {
  //     console.log( err );
  //   } );
  // }

  onSubmit() {
    this.donate.branchid = '265';
    this.donate.donorid = 'Donor 265';
    // this.donate.amount = 1545;
    console.log( this.donate );
      this.donateservice.createDonate(this.donate).subscribe( res => {
        console.log( res.id );
        this.router.navigate( ['/donate'] );

      }, err => {
        console.log( err );

        this.errorMessage = 'An Error Saving the Post';
      } );

  }
}
