import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import {Bloodstock} from '../../stock/bloodstock/bloodstock';
import {BloodstockService} from '../../stock/bloodstock/bloodstock.service';

@Component({
  selector: 'app-addblood',
  templateUrl: './addblood.component.html',
  styleUrls: ['./addblood.component.css'],
  providers:[BloodstockService]
})
export class AddbloodComponent implements OnInit {
  bloodstock: Bloodstock = new Bloodstock();
newval= 0;
  constructor(private bloodstockservice: BloodstockService , private router: Router) { }

  ngOnInit() {
    this.bloodstock.id = '5ccbe92dc87735419c995872';
    this.bloodstock.branchid = 'bra 41';
    this.bloodstock.stockid = "stock 1245";

  }
  onSubmit() {
    console.log(this.bloodstock);
    this.bloodstock.available = String( 256 + this.newval );
    this.bloodstockservice.updateBloodstock(this.bloodstock).subscribe( res => {
      console.log( res.id );
      this.router.navigate( ['/addblood'] );

    }, err => {
      console.log( err );

      // this.errorMessage = 'An Error Saving the Post';
    } );
  }
}
