import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {Transferblood} from './transferblood';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Headers, Http} from '@angular/http';
@Injectable()
export class TransferbloodService {


  serverUrl = 'http://localhost:3000/api';
  constructor(private  http: Http) { }
  headers = new Headers({
    'Content-Type': 'application/json',
  });
  getTransfer(): Observable<Transferblood[]> {
    // const url = this.serverUrl + '/donationcenters';
    const url = 'http://localhost:3000/api/transfers';
    return this.http.get(url, {headers: this.headers}).map(res => res.json()).catch(err => {
      return Observable.throw(err);
    });
  }

  askBlood(transferblood: Transferblood): Observable<any> {
    const  url = this.serverUrl + '/transfers';
    return this.http.post(url, transferblood, { headers: this.headers }).map(res => res.json()).catch(err => {

      return Observable.throw(err);

    });
  }
  provideBlood(tf: Transferblood): Observable<any> {
    const  url = this.serverUrl + '/transfers/' + tf.id;
    return this.http.put(url, tf, { headers: this.headers }).map(res => res.json()).catch(err => {
      return Observable.throw(err);

    });
  }

  cancelRequest(id: String): Observable<Transferblood[]> {
    const  url = this.serverUrl + '/transfers/' + id;
    return this.http.delete(url, { headers: this.headers }).map(res => res.json()).catch(err => {
      return Observable.throw(err);

    });
  }

  // transferDetail

}
