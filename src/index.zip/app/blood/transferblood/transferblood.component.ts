import { Component, OnInit } from '@angular/core';
import {Transferblood} from './transferblood';
import {TransferbloodService} from './transferblood.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-transferblood',
  templateUrl: './transferblood.component.html',
  styleUrls: ['./transferblood.component.css'],
  providers: [TransferbloodService]
})
export class TransferbloodComponent implements OnInit {
  transferblood: Transferblood= new Transferblood();

  constructor( private transferbloodservice: TransferbloodService , private router: Router) { }
  ngOnInit() {
// this.transferblood = null;
  }
  onAskBlood() {
    console.log(this.transferblood);
    this.transferblood.requestbranchid = "20";
    this.transferblood.status = false;
    this.transferbloodservice.askBlood(this.transferblood).subscribe( res => {
      console.log( res.id );
      this.router.navigate( ['/transferblood'] );
      this.transferblood = null;

    }, err => {
      console.log( err );

      // this.errorMessage = 'An Error Saving the Post';
    } );
  }
  onProvideBlood() {
    console.log(this.transferblood);
    this.transferblood.id = '5cd76b843340d25558bed89c';
    this.transferblood.providerbranchid = '20';
    this.transferblood.status = true;
    // this.bloodstock.available = String( 25610 - this.newval );
    this.transferbloodservice.provideBlood(this.transferblood).subscribe( res => {
      console.log( res.id );
      this.router.navigate( ['/transferblood'] );

    }, err => {
      console.log( err );

      // this.errorMessage = 'An Error Saving the Post';
    } );
  }

}
