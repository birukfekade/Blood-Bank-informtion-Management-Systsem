export class Transferblood {
  constructor(
    public id?: string,
    public providerbranchid?: string,
    public requestbranchid?: string,
    public requestedamount?: number,
    public privodedamount?: number,
    public type?: string,
    public status?: boolean
  )
  {
  }
}
