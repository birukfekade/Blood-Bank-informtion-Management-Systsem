import { Component, OnInit } from '@angular/core';
import {User} from './user';
import {AuthenticateService} from './authenticate.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-authenticate',
  templateUrl: './authenticate.component.html',
  styleUrls: ['./authenticate.component.css'],
  providers: [AuthenticateService]
})
export class AuthenticateComponent implements OnInit {


public active = false;
user: User = new User();
  constructor(private authenticateservice: AuthenticateService,
  private  router: Router) { }

  ngOnInit() {
  }

  onLogin() {
   // console.log('Login Tapped', this.user);
this.active = true;
   const user = this.user;
   this.authenticateservice.login(user.username, user.password).subscribe(response => {
console.log(response);
// save the cookie
//  const currentuser = response.user;
this.authenticateservice.setUser(response.user);

const  token = response.id;
this.authenticateservice.setToken(token);
// Routing
     this.router.navigate(['/profile']);
   },
     err => {
     console.log(err);
     }
     );
  }

}
