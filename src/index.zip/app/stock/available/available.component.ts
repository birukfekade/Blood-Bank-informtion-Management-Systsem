import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-available',
  templateUrl: './available.component.html',
  styleUrls: ['./available.component.css']
})
export class AvailableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
