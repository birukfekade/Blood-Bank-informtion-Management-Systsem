import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-used',
  templateUrl: './used.component.html',
  styleUrls: ['./used.component.css']
})
export class UsedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
