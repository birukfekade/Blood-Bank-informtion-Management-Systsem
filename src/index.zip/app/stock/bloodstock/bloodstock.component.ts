import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import 'datatables.net';
import {Bloodstock} from './bloodstock';
import {BloodstockService} from './bloodstock.service';
@Component({
  selector: 'app-bloodstock',
  templateUrl: './bloodstock.component.html',
  styleUrls: ['./bloodstock.component.css'],
  providers: [BloodstockService]
})
export class BloodstockComponent implements OnInit {

  // public data =
  //   [{
  //     'name': 'Anna',
  //     'age': '20',
  //     'lastName': 'Konda'
  //
  //   },
  //     {
  //       'name': 'Selomon',
  //       'age': '36',
  //       'lastName': 'Kelemu'
  //     },
  //     {
  //       'name': 'Zekariyas',
  //       'age': '58',
  //       'lastName': 'Feysel'
  //     },
  //
  //     {
  //       'name': 'Anna',
  //       'age': '20',
  //       'lastName': 'Konda'
  //     },
  //     {
  //       'name': 'Selomon',
  //       'age': '36',
  //       'lastName': 'Kelemu'
  //     },
  //     {
  //       'name': 'Zekariyas',
  //       'age': '58',
  //       'lastName': 'Shemsu'
  //     },
  //
  //     {
  //       'name': 'Fissha',
  //       'age': '47',
  //       'lastName': 'Interessierts'
  //     }];

  // public tableWidget: any;

  // public selectedName= '';

  bloodstocks: Bloodstock[] = [];
  constructor(private bloodstockservice: BloodstockService) { }

  ngOnInit() {


this.pop();

    $(document).ready(function () {
      const dataTable = $('#example').DataTable({
        'scrollX': true,
        // 'processing' : true,
        // 'serverSide': true,
        // 'scrollY' : '350px',
        // 'scrollCollapse' : true,
    //     'ajax': {
    //       url : this.dataTable.data ,
    // }



    });
    });

  }

  // ngAfterViewInit() {
  //   this.initDatatable();
  // }
  //
  // private initDatatable(): void {
  //   // debugger;
  //   const exampleId: any = $('#example');
    // this.tableWidget.destroy();
    // this.tableWidget = null;
    // this.tableWidget = exampleId.DataTable({
    //   select: true,
    //
    // });
      // $('#example')
      //   .removeClass('display')
      //   .addClass('table table-striped table-bordered')
  // }

  // private reInitDatatable(): void {
  //   if (this.tableWidget) {
  //     this.tableWidget.destroy();
  //     this.tableWidget = null;
  //   }
  //   setTimeout(() => this.initDatatable(), 0);
  // }

pop() {
    this.bloodstockservice.getBloodstock().subscribe(res => {
      console.log(res);
      this.bloodstocks = res as Bloodstock[];
    }, err => {
      console.log(err);
    });
}

}
