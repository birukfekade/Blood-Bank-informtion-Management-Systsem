export class Bloodstock {
  constructor(
    public id?: string,
    public stockid?: string,
    public branchid?: string,
    public  type?: string,
    public available?: string,
    public  used?: string
  )
  {
  }

}
