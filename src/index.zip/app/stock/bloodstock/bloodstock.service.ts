import { Injectable } from '@angular/core';
import {Http ,Headers} from '@angular/http';
import {Bloodstock} from './bloodstock';
import {Observable} from 'rxjs';


@Injectable()
export class BloodstockService {
  serverUrl = 'http://localhost:3000/api';

  constructor(private http: Http) {
  }

  headers = new Headers( {
    'Content-Type': 'application/json',
  } );

  getBloodstock(): Observable<Bloodstock[]> {
    const url = this.serverUrl + '/stocks';
    return this.http.get( url, {headers: this.headers} ).map( res => res.json() ).catch( err => {
      return Observable.throw( err );
    } );
  }

  createBloodstock(bloodstock: Bloodstock): Observable<any> {
    const url = this.serverUrl + '/stocks';
    return this.http.post( url, bloodstock, {headers: this.headers} ).map( res => res.json() ).catch( err => {
      return Observable.throw( err );
    } );
  }
  updateBloodstock(bloodstock: Bloodstock): Observable<any> {
    const  url = this.serverUrl + '/stocks/' + bloodstock.id;
    return  this.http.put(url, bloodstock, {headers: this.headers}).map( res => res.json()).catch( err => {
      return  Observable.throw(err);
    });
  }
  deleteBloodstock(id: String): Observable<Bloodstock[]> {
    const url = this.serverUrl + '/stocks/' + id;
    return  this.http.delete(url, {headers: this.headers}).map( res => res.json()).catch( err => {
      return Observable.throw(err);
    });
  }
}
