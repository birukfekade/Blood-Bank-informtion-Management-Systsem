import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import 'datatables.net';
import {Donor} from './donor';
import {Staff} from '../staff/staff';
import {DonorService} from './donor.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-donor',
  templateUrl: './donor.component.html',
  styleUrls: ['./donor.component.css', '../../../assets/css/jquery.dataTables.css'],
  providers: [DonorService]
})
export class DonorComponent implements OnInit {

  public data =
    [{
      'donorid': 'Donor 0025',
      'firstname': 'Solomon',
      'lastname' : 'Ahmed',
      'gfname': 'Zelalem',
      'title' : 'Software Engineer',
      'date': 'Oct 14, 2018',
      'age': '25',
      'sex' : 'Male',
      'occupation': 'Developer',
      'city': 'Addis Ababa',
      'region': 'Bole',
      'zone': 'zone 5',
      'woreda' : '5',
      'kebele' : '20',
      'housenumber' : 'BHB 720',
      'telresidence': '0116584236',
      'teloffice': '0116851015',
      'phonenumber': '0910561147',
      'email': 'sol@gmail.com',
      'pobox': 'Addis785698',
      'bloodtype': 'A+'
    }
    ];

  public tableWidget: any;
  donors: Donor[] = [];
  donor: Donor = new Donor();

  public selectedName= '';


  constructor(private donorservice: DonorService, private  router: Router) { }

  ngOnInit() {
    $(document).ready(function () {
      const dataTable = $('#example').DataTable({
        'scrollX': true,
      });
    });

  }

  onSubmit() {
    console.log(this.donor);
    this.donorservice.createDonor( this.donor ).subscribe( res => {
      console.log( res.id );
      this.router.navigate( ['/staff'] );

    }, err => {
      console.log( err );
    } );
  }
  ngAfterViewInit() {
    this.initDatatable();
  }

  private initDatatable(): void {
    debugger;
    const exampleId: any = $('#example');
    this.tableWidget = exampleId.DataTable({
      select: true,
      'scrollX': true
    });
    //   $('#example')
    //     .removeClass('display')
    //     .addClass('table table-striped table-bordered')
  }

  private reInitDatatable(): void {
    if (this.tableWidget) {
      this.tableWidget.destroy();
      this.tableWidget = null;
    }
    setTimeout(() => this.initDatatable(), 0);
  }


  public selectRow(index: number, row: any) {
    this.selectedName = 'row#' + index + ' ' + row.name;
  }

}
