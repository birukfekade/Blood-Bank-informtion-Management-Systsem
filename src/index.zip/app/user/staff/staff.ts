export class Staff {
  constructor(
    public id?: string,
    public staffid?: string,
    public firstname?: string,
    public  lastname?: string,
    public  gfathername?: string,
    public sex?: string,
    public  title?: string,
    public  branchid?: string,
    public  telephone?: string,
    public phonenumber?: string,
    public  email?: string,
    public  pobox?: string
  )
  {
  }

}
