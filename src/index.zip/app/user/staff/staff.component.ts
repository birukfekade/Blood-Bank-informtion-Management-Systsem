import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import {Staff} from './staff';
import {StaffService} from './staff.service';
import {Router} from '@angular/router';
import {User} from '../../authenticate/user';
import {AuthenticateService} from '../../authenticate/authenticate.service';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css', '../../../assets/css/jquery.dataTables.css'],
  providers: [StaffService]
})
export class StaffComponent implements OnInit {
  staffs: Staff[] = [];
  staff: Staff = new Staff();
  user: User = new User();
  updatedData: Staff = new Staff();
  errorMessage = '';
  public tableWidget: any;


  public selectedId = '';
  public selectedStaffId = '';
  public selectedfname = '';
  public selectedlname = '';
  public selectedgname = '';
  public selectedsex = '';
  public selectedtitle = '';
  public selectedbranchid = '';
  public selectedtelephone = '';
  public selectedphonenumber = '';
  public selectedemail = '';
  public selectedpobox = '';

  constructor(private staffservice: StaffService , private authservice: AuthenticateService, private  router: Router) {
  }

  ngOnInit(): void {
    this.pop();


    $( document ).ready( function () {
      const dataTable = $( '#example' ).DataTable( {
        'scrollX': true,
        // 'ajax': {
        //   url : this.dona ,
        // }
      } );

    });

  //   $('#example')
  //     .removeClass('display')
  //     .addClass('table table-striped table-bordered');
  }


  pop() {
    this.staffservice.getStaffs().subscribe( res => {
      console.log( res );
      this.staffs = res as Staff[];
    }, err => {
      console.log( err );
    } );
  }

  register(user: User) {
    this.authservice.register(this.user).subscribe( resu => {
      this.router.navigate( ['/staff'] );
      console.log('Registerd');
    }, error1 => {
      console.log(error1);
    });
  }

  onSubmit() {
    console.log(this.staff);
    this.staffservice.createStaff( this.staff ).subscribe( res => {
      // console.log( res.id);
      // console.log(res.branchId);
      this.user.email = res.email;
      this.user.password = '12345';
      this.user.branchid = res.branchId;
      this.user.role = res.title;
      this.register(this.user);

      // this.router.navigate( ['/staff'] );

    }, err => {
      console.log( err );

      this.errorMessage = 'An Error Saving the Post';
    } );
  }

  public selectRow(index: number, post: any, value: string) {
    this.selectedId = post.id;
    this.selectedStaffId = post.staffid;
    this.selectedfname = post.firstname;
    this.selectedlname = post.lastname;
    this.selectedgname = post.gfathername;
    this.selectedsex = post.sex;
    this.selectedtitle = post.title;
    this.selectedbranchid = post.branchid;
    this.selectedtelephone = post.telephone;
    this.selectedphonenumber = post.phonenumber;
    this.selectedemail = post.email;
    this.selectedpobox = post.pobox;

    if (value === 'none') {

    } else if (value === 'delete') {
      this.onDelete();
    }
  }

  onUpdate() {

    this.updatedData = { id: this.selectedId, staffid: this.selectedStaffId, firstname: this.selectedfname, lastname: this.selectedlname, gfathername: this.selectedgname,
      sex: this.selectedsex, title: this.selectedtitle, branchid: this.selectedbranchid, telephone: this.selectedtelephone, phonenumber: this.selectedphonenumber,
      email: this.selectedemail, pobox: this.selectedpobox };

    this.staffservice.updateStaff( this.updatedData ).subscribe( res => {
      this.pop();
    } );
  };


  onDelete() {
    this.staffservice.deleteStaff( this.selectedId ).subscribe( res => {
      this.pop();
    } );
  };

}
