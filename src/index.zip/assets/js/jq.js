$(document).ready(function () {
  var dataTable = $('#example').DataTable({
    "scrollX": true,
  });
});
