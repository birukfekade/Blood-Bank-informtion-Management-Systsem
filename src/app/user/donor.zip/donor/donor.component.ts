import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import 'datatables.net';
import {Donor} from './donor';
import {Staff} from '../staff/staff';
import {DonorService} from './donor.service';
import {Router} from '@angular/router';
import {DateFormatter} from '@angular/common/src/pipes/intl';
import {StaffService} from '../staff/staff.service';

@Component({
  selector: 'app-donor',
  templateUrl: './donor.component.html',
  styleUrls: ['./donor.component.css', '../../../assets/css/jquery.dataTables.css'],
  providers: [DonorService, StaffService]
})
export class DonorComponent implements OnInit {
public trialdate;
  public tableWidget: any;
  donors: Donor[] = [];
  dnrs: Donor[] = [];
  donor: Donor = new Donor();
  recent;

  public selectedName= '';

  // today = Date();
  internalDate = new Date;

  constructor(private donorservice: DonorService, private staffservice: StaffService, private  router: Router) { }

  ngOnInit() {
    this.pop();
    $(document).ready(function () {
      const dataTable = $('#example').DataTable({
        'scrollX': true,
      });
    });

  }
  pop() {

    this.donorservice.getDonors().subscribe(res => {
      console.log(res);
      this.recent = res;
      this.donor.sex = 'Male';
      // this.recent.sex = 'male';
      this.dnrs = this.recent as Donor[];
      for (const dean of this.dnrs){
             const reg = new Date(dean.regdate);
             dean.regdate = reg.toDateString();
         const day = new Date();
        dean.age = new Date(dean.age);
        let age = day.getFullYear() - dean.age.getFullYear();
        const m = day.getMonth() - dean.age.getMonth();
        if (m < 0 || (m === 0 && day.getDate() < dean.age.getDate())) {
          age--;
          dean.age = age;
        }        else {
          dean.age = 0;
        }
         // dean.sex = 'Male';
         // dean.regdate = dean.regdate.getDay();

      }
      this.donors = this.dnrs;
    }, err => {
      console.log(err);
    });
    // this.staffservice.getStaffs().subscribe(res => {
    //   console.log(res);
    // }, error1 => {
    //   console.log(error1);
    // });

  }

  onSubmit() {
    console.log(this.donor);
    this.donorservice.createDonor( this.donor ).subscribe( res => {
      console.log( res.id );
      this.router.navigate( ['/donor'] );

    }, err => {
      console.log( err );
    } );
  }

  ontry() {
    const  today = new  Date();
    // const b = a.getDate();
    // const c = a.toISOString();
    // console.log(a.toISOString());
    // console.log(today.toDateString(),'Heyy');
    console.log(today.getDate(),'Heyy');

    // this.trialdate = this.today.toISOString().substr(0, 10);
// this.trialdate.subscribe(value => this.internalDate = new Date(value))
    this.internalDate = new Date(this.trialdate);
    const birthday = this.internalDate;

    // this.internalDate = new Date(this.trialdate).;
    // this.trialdate = new Date().toISOString();
    console.log(this.trialdate , 'trial');
    console.log(this.internalDate , 'internal');
    console.log(today.toDateString(), 'toda');

    console.log(birthday , 'vstria');

    // var dob = //Here Im getting dob
    // var today = new Date();
    // var birthday= new Date(dob);
    var age = today.getFullYear() - birthday.getFullYear();
    var m = today.getMonth() - birthday.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthday.getDate())) {
      age--;
      console.log(age , 'My Age');
    }
    // var today =
    // ublic current_date=new Date();
     // this.donor.id ="donor2417";
    this.donor.donorid = 'string';
     this.donor.firstname = 'string';
      this.donor.lastname = 'string';
      this.donor.gfathername = 'string';
      this.donor.title = 'string';
      this.donor.regdate = today;
    this.donor.age = birthday;
    // 2019-06-01T08:10:41.046Z

    this.donor.sex = 'string';
      this.donor.occupation = 'string';
      this.donor.city = 'string';
      this.donor.region = 'string';
      this.donor.zone = 'string';
      this.donor.woreda = 'string';
      this.donor.kebele = 'string';
      this.donor.housenumber = 'string';
      this.donor.telephoneresidence = 'string';
      this.donor.telephoneoffice = 'string';
      this.donor.phone = 'string';
      this.donor.email = 'string@gmail.com';
      this.donor.pobox = 'string';
      this.donor.bloodtype = 'string';
this.donorservice.createDonor(this.donor).subscribe( res =>{
  console.log(res);
}, error1 => {
  console.log(error1);
});

  }
  // ngAfterViewInit() {
  //   this.initDatatable();
  // }
  //
  // private initDatatable(): void {
  //   // debugger;
  //   const exampleId: any = $('#example');
  //   this.tableWidget = exampleId.DataTable({
  //     select: true,
  //     'scrollX': true
  //   });
    //   $('#example')
    //     .removeClass('display')
    //     .addClass('table table-striped table-bordered')
  // }

  // private reInitDatatable(): void {
  //   if (this.tableWidget) {
  //     this.tableWidget.destroy();
  //     this.tableWidget = null;
  //   }
  //   setTimeout(() => this.initDatatable(), 0);
  // }


  public selectRow(index: number, row: any) {
    this.selectedName = 'row#' + index + ' ' + row.name;
  }

}
